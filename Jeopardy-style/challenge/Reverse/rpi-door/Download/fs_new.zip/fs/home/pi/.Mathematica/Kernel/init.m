(** User Mathematica initialization file **)

